# [games/mob-control-3d/PLAYTEST_LOG.md] Archived 1 entries at 2026-11-15 20:11:06

### [2026-11-12 16:46:43] 自主试玩巡检报告 — **PASS** (20/20 项通过)
- ✅ **Title Screen Visible**: `visible=True`
- ✅ **Character Click No Jump**: `launch_active=True`
- ✅ **Scene Selection Buttons Removed**: `no_theme_btns=True`
- ✅ **Weekly Leaderboard Refresh Text**: `指挥官3303未上榜0 关每周一刷新（剩3天7时）`
- ✅ **Rename Blocks <100k Gold**: ` 改名需花费 100,000 金币（当前：160 金币）`
- ✅ **All 7 Characters Cycle & HQ 2D Sprites**: `unique_races=7, all_hq2d=True`
- ✅ **Multi-Branch Skill Allocation & Free Character Switch & Meta/Skins Tabs**: `{"ok": true, "saved": {"swarm_t1": 2, "gate_t2": 1, "tycoon_t4": 1}, "metaCount": 6, "skinCount": 6, "raceSwitch": "波波族 -> 布丁族"}`
- ✅ **In-Run Parameter Upgrade Labels Active**: `costs=0/8秒 / 1/12击杀 / 14/25出兵 / 1/30攻城`
- ✅ **Scene Special Effect & Active-Character-Only Talent Badge in Battle HUD**: `buffs=齿轮城·蒸汽超压`
- ✅ **Zero NaN/Undefined in DOM Text**: `bad_tokens=[]`
- ✅ **MC-1 Dynamic Gate Charging (-6 -> +1 -> +3 -> +5) & Frame Color Transition**: `prog=['-6', '-5', '-4', '-3', '-2', '-1', '+1', '+3', '+5'], colorChanged=True`
- ✅ **MC-1 Jelly Giant Gate (2x HP/ATK) & Frosting Shield Gate (Gear/Barrel Immunity)**: `{"hasJelly": true, "hasFrost": true, "jelly2x": true, "blockGear": true, "blockBarrel": true}`
- ✅ **MC-2 Dual Lateral Steam Shield Sub-Towers (0.24x -> 0.58x -> 1.0x & Overload Shatter)**: `{"s5": 2, "s10": 2, "mults": [0.24, 0.58, 1], "overload": true}`
- ✅ **MC-2 Boss Ground Half-Bridge Telegraph & High-Pressure Steam Sweep Lane Isolation**: `{"telegraph": true, "sweptHit": true, "safeLane": true}`
- ✅ **MC-3 25s Candy Vault Bonus Heist (Zero Red Enemies & Gold + Skin Shard Burst)**: `{"vaults": 5, "dur": 25, "zeroRed": true, "broken": true, "goldDelta": 1306, "shards": 2}`
- ✅ **MC-3 Endless Workshop Defense (Lobby Entry, Wave Escalation, Mutant Giants & Best Medal)**: `{"lobbyBtn": true, "wave": 3, "brutes": 4, "bestWave": 3, "medal": "秘银壁垒勋章"}`
- ✅ **Mobile 390x844 Zero Horizontal Overflow**: `overflow=0px`
- ✅ **Zero Page Exceptions**: `[]`
- ✅ **Zero Console Errors**: `[]`
- ✅ **Zero Failed Asset Requests**: `[]`

# [games/mob-control-3d/PLAYTEST_LOG.md] Archived 1 entries at 2026-11-15 20:37:07

### [2026-11-13 21:18:39] 自主试玩巡检报告 — **PASS** (22/22 项通过)
- ✅ **Title Screen Visible**: `visible=True`
- ✅ **Character Click No Jump**: `launch_active=True`
- ✅ **Scene Selection Buttons Removed**: `no_theme_btns=True`
- ✅ **Weekly Leaderboard Refresh Text**: `指挥官6669未上榜0 关每周一刷新（剩2天2时）`
- ✅ **Rename Blocks <100k Gold**: ` 改名需花费 100,000 金币（当前：160 金币）`
- ✅ **All 7 Characters Cycle & HQ 2D Sprites**: `unique_races=7, all_hq2d=True`
- ✅ **Multi-Branch Skill Allocation & Free Character Switch & Meta/Skins Tabs**: `{"ok": true, "saved": {"swarm_t1": 2, "gate_t2": 1, "tycoon_t4": 1}, "metaCount": 6, "skinCount": 6, "raceSwitch": "波波族 -> 布丁族"}`
- ✅ **In-Run Parameter Upgrade Labels Active**: `costs=0/8秒 / 1/12击杀 / 11/25出兵 / 1/30攻城`
- ✅ **Scene Special Effect & Active-Character-Only Talent Badge in Battle HUD**: `buffs=齿轮城·蒸汽超压`
- ✅ **Zero NaN/Undefined in DOM Text**: `bad_tokens=[]`
- ✅ **MC-1 Dynamic Gate Charging (-6 -> +1 -> +3 -> +5) & Frame Color Transition**: `prog=['-6', '-5', '-4', '-3', '-2', '-1', '+1', '+3', '+5'], colorChanged=True`
- ✅ **MC-1 Jelly Giant Gate (2x HP/ATK) & Frosting Shield Gate (Gear/Barrel Immunity)**: `{"hasJelly": true, "hasFrost": true, "jelly2x": true, "blockGear": true, "blockBarrel": true}`
- ✅ **MC-2 Dual Lateral Steam Shield Sub-Towers (0.24x -> 0.58x -> 1.0x & Overload Shatter)**: `{"s5": 2, "s10": 2, "mults": [0.24, 0.58, 1], "overload": true}`
- ✅ **MC-2 Boss Ground Half-Bridge Telegraph & High-Pressure Steam Sweep Lane Isolation**: `{"telegraph": true, "sweptHit": true, "safeLane": true}`
- ✅ **MC-3 25s Candy Vault Bonus Heist (Zero Red Enemies & Gold + Skin Shard Burst)**: `{"vaults": 5, "dur": 25, "zeroRed": true, "broken": true, "goldDelta": 1309, "shards": 2}`
- ✅ **MC-3 Endless Workshop Defense (Lobby Entry, Wave Escalation, Mutant Giants & Best Medal)**: `{"lobbyBtn": true, "wave": 3, "brutes": 4, "bestWave": 3, "medal": "秘银壁垒勋章"}`
- ✅ **MC-4 Scatter & Rainbow Weapons (HUD Cycle, Zero SVG/Emoji, RGBA PNGs, Bounce & Pierce)**: `{"labels": ["速射", "散弹", "彩虹"], "imgs": [true, true, true], "fan": 11, "bounced": true, "rainbowHit": true}`
- ✅ **MC-4 Tactical Airdrop Crate (Drop, Collect, 3x 8s Frenzy Buffs, Clean Reset & Bonus Heist Skip)**: `{"drop": true, "collect": true, "dual": true, "freeze": true, "giants": true, "reset": true, "skipBonus": true}`
- ✅ **Mobile 390x844 Zero Horizontal Overflow**: `overflow=0px`
- ✅ **Zero Page Exceptions**: `[]`
- ✅ **Zero Console Errors**: `[]`
- ✅ **Zero Failed Asset Requests**: `[]`

# [games/mob-control-3d/PLAYTEST_LOG.md] Archived 1 entries at 2026-11-15 22:57:58

### [2026-11-13 21:20:59] 自主试玩巡检报告 — **PASS** (22/22 项通过)
- ✅ **Title Screen Visible**: `visible=True`
- ✅ **Character Click No Jump**: `launch_active=True`
- ✅ **Scene Selection Buttons Removed**: `no_theme_btns=True`
- ✅ **Weekly Leaderboard Refresh Text**: `指挥官8008未上榜0 关每周一刷新（剩2天2时）`
- ✅ **Rename Blocks <100k Gold**: ` 改名需花费 100,000 金币（当前：160 金币）`
- ✅ **All 7 Characters Cycle & HQ 2D Sprites**: `unique_races=7, all_hq2d=True`
- ✅ **Multi-Branch Skill Allocation & Free Character Switch & Meta/Skins Tabs**: `{"ok": true, "saved": {"swarm_t1": 2, "gate_t2": 1, "tycoon_t4": 1}, "metaCount": 6, "skinCount": 6, "raceSwitch": "波波族 -> 布丁族"}`
- ✅ **In-Run Parameter Upgrade Labels Active**: `costs=0/8秒 / 2/12击杀 / 13/25出兵 / 1/30攻城`
- ✅ **Scene Special Effect & Active-Character-Only Talent Badge in Battle HUD**: `buffs=齿轮城·蒸汽超压`
- ✅ **Zero NaN/Undefined in DOM Text**: `bad_tokens=[]`
- ✅ **MC-1 Dynamic Gate Charging (-6 -> +1 -> +3 -> +5) & Frame Color Transition**: `prog=['-6', '-5', '-4', '-3', '-2', '-1', '+1', '+3', '+5'], colorChanged=True`
- ✅ **MC-1 Jelly Giant Gate (2x HP/ATK) & Frosting Shield Gate (Gear/Barrel Immunity)**: `{"hasJelly": true, "hasFrost": true, "jelly2x": true, "blockGear": true, "blockBarrel": true}`
- ✅ **MC-2 Dual Lateral Steam Shield Sub-Towers (0.24x -> 0.58x -> 1.0x & Overload Shatter)**: `{"s5": 2, "s10": 2, "mults": [0.24, 0.58, 1], "overload": true}`
- ✅ **MC-2 Boss Ground Half-Bridge Telegraph & High-Pressure Steam Sweep Lane Isolation**: `{"telegraph": true, "sweptHit": true, "safeLane": true}`
- ✅ **MC-3 25s Candy Vault Bonus Heist (Zero Red Enemies & Gold + Skin Shard Burst)**: `{"vaults": 5, "dur": 25, "zeroRed": true, "broken": true, "goldDelta": 1306, "shards": 2}`
- ✅ **MC-3 Endless Workshop Defense (Lobby Entry, Wave Escalation, Mutant Giants & Best Medal)**: `{"lobbyBtn": true, "wave": 3, "brutes": 4, "bestWave": 3, "medal": "秘银壁垒勋章"}`
- ✅ **MC-4 Scatter & Rainbow Weapons (HUD Cycle, Zero SVG/Emoji, RGBA PNGs, Bounce & Pierce)**: `{"labels": ["速射", "散弹", "彩虹"], "imgs": [true, true, true], "fan": 11, "bounced": true, "rainbowHit": true}`
- ✅ **MC-4 Tactical Airdrop Crate (Drop, Collect, 3x 8s Frenzy Buffs, Clean Reset & Bonus Heist Skip)**: `{"drop": true, "collect": true, "dual": true, "freeze": true, "giants": true, "reset": true, "skipBonus": true}`
- ✅ **Mobile 390x844 Zero Horizontal Overflow**: `overflow=0px`
- ✅ **Zero Page Exceptions**: `[]`
- ✅ **Zero Console Errors**: `[]`
- ✅ **Zero Failed Asset Requests**: `[]`

# [games/mob-control-3d/PLAYTEST_LOG.md] Archived 1 entries at 2026-11-15 23:08:18

### [2026-11-15 08:24:53] 自主试玩巡检报告 — **PASS** (25/25 项通过)
- ✅ **Title Screen Visible**: `visible=True`
- ✅ **Character Click No Jump**: `launch_active=True`
- ✅ **Scene Selection Buttons Removed**: `no_theme_btns=True`
- ✅ **Weekly Leaderboard Refresh Text**: `指挥官1900未上榜0 关每周一刷新（剩15时35分）`
- ✅ **Rename Blocks <100k Gold**: ` 改名需花费 100,000 金币（当前：160 金币）`
- ✅ **All 7 Characters Cycle & HQ 2D Sprites**: `unique_races=7, all_hq2d=True`
- ✅ **Multi-Branch Skill Allocation & Free Character Switch & Meta/Skins Tabs**: `{"ok": true, "saved": {"swarm_t1": 2, "gate_t2": 1, "tycoon_t4": 1}, "metaCount": 6, "skinCount": 6, "raceSwitch": "波波族 -> 布丁族"}`
- ✅ **In-Run Parameter Upgrade Labels Active**: `costs=0/8秒 / 1/12击杀 / 14/25出兵 / 1/30攻城`
- ✅ **Scene Special Effect & Active-Character-Only Talent Badge in Battle HUD**: `buffs=齿轮城·蒸汽超压`
- ✅ **Zero NaN/Undefined in DOM Text**: `bad_tokens=[]`
- ✅ **MC-1 Dynamic Gate Charging (-6 -> +1 -> +3 -> +5) & Frame Color Transition**: `prog=['-6', '-5', '-4', '-3', '-2', '-1', '+1', '+3', '+5'], colorChanged=True`
- ✅ **MC-1 Jelly Giant Gate (2x HP/ATK) & Frosting Shield Gate (Gear/Barrel Immunity)**: `{"hasJelly": true, "hasFrost": true, "jelly2x": true, "blockGear": true, "blockBarrel": true}`
- ✅ **MC-2 Dual Lateral Steam Shield Sub-Towers (0.24x -> 0.58x -> 1.0x & Overload Shatter)**: `{"s5": 2, "s10": 2, "mults": [0.24, 0.58, 1], "overload": true}`
- ✅ **MC-2 Boss Ground Half-Bridge Telegraph & High-Pressure Steam Sweep Lane Isolation**: `{"telegraph": true, "sweptHit": true, "safeLane": true}`
- ✅ **MC-3 25s Candy Vault Bonus Heist (Zero Red Enemies & Gold + Skin Shard Burst)**: `{"vaults": 5, "dur": 25, "zeroRed": true, "broken": true, "goldDelta": 1309, "shards": 2}`
- ✅ **MC-3 Endless Workshop Defense (Lobby Entry, Wave Escalation, Mutant Giants & Best Medal)**: `{"lobbyBtn": true, "wave": 3, "brutes": 4, "bestWave": 3, "medal": "秘银壁垒勋章"}`
- ✅ **MC-4 Scatter & Rainbow Weapons (HUD Cycle, Zero SVG/Emoji, RGBA PNGs, Bounce & Pierce)**: `{"labels": ["速射", "散弹", "彩虹"], "imgs": [true, true, true], "fan": 11, "bounced": true, "rainbowHit": true}`
- ✅ **MC-4 Tactical Airdrop Crate (Drop, Collect, 3x 8s Frenzy Buffs, Clean Reset & Bonus Heist Skip)**: `{"drop": true, "collect": true, "dual": true, "freeze": true, "giants": true, "reset": true, "skipBonus": true}`
- ✅ **MC-5 Steam Armored Payload Escort Mode (Lobby Entry, Charging, Overdrive, Barricade Ramming & Stronghold Persistence)**: `{"lobbyBtn": true, "bars": 4, "moved": true, "overdrive": true, "rams": 1, "broken": true, "clear": true, "bestPct": 100, "hud": "战车护送 · 推进 0%"}`
- ✅ **MC-5 Bobo Squad Paint & Material Workshop (4 Finishes + 6 Colorways, Live 3D Materials & 6x 256px RGBA PNGs)**: `{"finishCards": 4, "skinCards": 6, "skinCardH": 404, "rgba": [true, true, true, true, true, true], "switch": "candy_gloss->starlight_prism", "modes": [0, 1, 2, 3], "cannonChanged": true, "cartChanged": true}`
- ✅ **Desktop 2560x1278 Zero Horizontal Overflow (Lobby, Workshop & Escort)**: `max_overflow=0px`
- ✅ **Mobile 390x844 Zero Horizontal Overflow**: `overflow=0px (lobby=0, workshop=0)`
- ✅ **Zero Page Exceptions**: `[]`
- ✅ **Zero Console Errors**: `[]`
- ✅ **Zero Failed Asset Requests**: `[]`
